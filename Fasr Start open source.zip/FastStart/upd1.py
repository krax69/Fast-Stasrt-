import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog
import subprocess
import json
import os


SCENARIOS_FILE = "scenarios.json"


class FastStart:
    def __init__(self, root):
        self.root = root
        self.root.title("🚀 Fast Start")
        self.root.geometry("900x550")
        self.root.configure(bg="#121212")

        self.scenarios = self.load_scenarios()

        title = tk.Label(
            root,
            text="🚀 Fast Start Manager",
            font=("Segoe UI", 22, "bold"),
            bg="#121212",
            fg="#00d4ff"
        )
        title.pack(pady=10)

        main_frame = tk.Frame(root, bg="#121212")
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)

        # Левая панель
        left_frame = tk.Frame(main_frame, bg="#1e1e1e")
        left_frame.pack(side="left", fill="y", padx=(0, 10))

        tk.Label(
            left_frame,
            text="Сценарии",
            font=("Segoe UI", 14, "bold"),
            bg="#1e1e1e",
            fg="white"
        ).pack(pady=10)

        self.scenario_list = tk.Listbox(
            left_frame,
            width=30,
            bg="#252525",
            fg="white",
            selectbackground="#00d4ff",
            font=("Segoe UI", 10),
            border=0
        )
        self.scenario_list.pack(fill="y", expand=True, padx=10)
        self.scenario_list.bind("<<ListboxSelect>>", self.load_programs)

        tk.Button(
            left_frame,
            text="➕ Создать",
            command=self.create_scenario,
            bg="#00d4ff",
            fg="black",
            relief="flat"
        ).pack(fill="x", padx=10, pady=3)

        tk.Button(
            left_frame,
            text="✏ Переименовать",
            command=self.rename_scenario,
            bg="#ffaa00",
            fg="black",
            relief="flat"
        ).pack(fill="x", padx=10, pady=3)

        tk.Button(
            left_frame,
            text="🗑 Удалить",
            command=self.delete_scenario,
            bg="#ff5555",
            fg="white",
            relief="flat"
        ).pack(fill="x", padx=10, pady=3)

        # Правая панель
        right_frame = tk.Frame(main_frame, bg="#1e1e1e")
        right_frame.pack(side="right", fill="both", expand=True)

        tk.Label(
            right_frame,
            text="Программы",
            font=("Segoe UI", 14, "bold"),
            bg="#1e1e1e",
            fg="white"
        ).pack(pady=10)

        self.program_list = tk.Listbox(
            right_frame,
            bg="#252525",
            fg="white",
            font=("Segoe UI", 10),
            border=0
        )
        self.program_list.pack(fill="both", expand=True, padx=10)

        btn_frame = tk.Frame(right_frame, bg="#1e1e1e")
        btn_frame.pack(fill="x", pady=10)

        tk.Button(
            btn_frame,
            text="➕ Добавить программу",
            command=self.add_program,
            bg="#00d4ff",
            fg="black",
            relief="flat"
        ).pack(side="left", padx=5)

        tk.Button(
            btn_frame,
            text="❌ Удалить программу",
            command=self.remove_program,
            bg="#ff5555",
            fg="white",
            relief="flat"
        ).pack(side="left", padx=5)

        tk.Button(
            btn_frame,
            text="🚀 Запустить сценарий",
            command=self.run_scenario,
            bg="#00ff88",
            fg="black",
            relief="flat",
            font=("Segoe UI", 10, "bold")
        ).pack(side="right", padx=5)

        self.refresh_scenarios()

    def load_scenarios(self):
        if os.path.exists(SCENARIOS_FILE):
            try:
                with open(SCENARIOS_FILE, "r", encoding="utf-8") as f:
                    return json.load(f)
            except:
                pass
        return {}

    def save_scenarios(self):
        with open(SCENARIOS_FILE, "w", encoding="utf-8") as f:
            json.dump(self.scenarios, f, ensure_ascii=False, indent=4)

    def refresh_scenarios(self):
        self.scenario_list.delete(0, tk.END)
        for name in self.scenarios:
            self.scenario_list.insert(tk.END, name)

    def get_selected_scenario(self):
        selection = self.scenario_list.curselection()
        if not selection:
            return None
        return self.scenario_list.get(selection[0])

    def create_scenario(self):
        name = simpledialog.askstring(
            "Создать сценарий",
            "Введите имя сценария:"
        )

        if name:
            if name in self.scenarios:
                messagebox.showerror("Ошибка", "Такой сценарий уже существует.")
                return

            self.scenarios[name] = []
            self.save_scenarios()
            self.refresh_scenarios()

    def rename_scenario(self):
        old_name = self.get_selected_scenario()

        if not old_name:
            return

        new_name = simpledialog.askstring(
            "Переименование",
            "Новое имя:",
            initialvalue=old_name
        )

        if new_name:
            self.scenarios[new_name] = self.scenarios.pop(old_name)
            self.save_scenarios()
            self.refresh_scenarios()

    def delete_scenario(self):
        name = self.get_selected_scenario()

        if not name:
            return

        if messagebox.askyesno(
            "Удаление",
            f"Удалить сценарий '{name}'?"
        ):
            del self.scenarios[name]
            self.save_scenarios()
            self.refresh_scenarios()
            self.program_list.delete(0, tk.END)

    def load_programs(self, event=None):
        self.program_list.delete(0, tk.END)

        name = self.get_selected_scenario()
        if not name:
            return

        for program in self.scenarios[name]:
            self.program_list.insert(tk.END, program)

    def add_program(self):
        scenario = self.get_selected_scenario()

        if not scenario:
            messagebox.showwarning(
                "Внимание",
                "Сначала выберите сценарий."
            )
            return

        path = filedialog.askopenfilename(
            title="Выберите программу",
            filetypes=[
                ("Программы", "*.exe"),
                ("Все файлы", "*.*")
            ]
        )

        if path:
            self.scenarios[scenario].append(path)
            self.save_scenarios()
            self.load_programs()

    def remove_program(self):
        scenario = self.get_selected_scenario()

        if not scenario:
            return

        selection = self.program_list.curselection()

        if not selection:
            return

        index = selection[0]

        del self.scenarios[scenario][index]

        self.save_scenarios()
        self.load_programs()

    def run_scenario(self):
        scenario = self.get_selected_scenario()

        if not scenario:
            return

        count = 0

        for program in self.scenarios[scenario]:
            try:
                subprocess.Popen(program)
                count += 1
            except Exception as e:
                messagebox.showerror(
                    "Ошибка",
                    f"Не удалось запустить:\n{program}\n\n{e}"
                )

        messagebox.showinfo(
            "Готово",
            f"Запущено программ: {count}"
        )


root = tk.Tk()



app = FastStart(root)
root.mainloop()